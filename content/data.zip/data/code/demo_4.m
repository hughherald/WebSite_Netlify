clc;clear;close all;
LW_init();
option_channel_sel=struct('type','channel','items',{{'P7','P8','CP3','CP4','PO7','PO8','CPz','POz','Oz'}},'suffix','sel_chan','is_save',0);
option_crop=struct('xcrop_chk',1,'xstart',0,'xend',0.6,'suffix','crop','is_save',0);

option=struct('filename','ep_S  9 sp_filter ica ds reref chan_interp butt sel_chan sub114 ses1.lw6');
lwdata= FLW_load.get_lwdata(option);
lwdata= FLW_selection.get_lwdata(lwdata,option_channel_sel);
lwdata= FLW_crop_epochs.get_lwdata(lwdata,option_crop);
data_target=squeeze(lwdata.data);

option=struct('filename','ep_S 10 sp_filter ica ds reref chan_interp butt sel_chan sub114 ses1.lw6');
lwdata= FLW_load.get_lwdata(option);
lwdata= FLW_selection.get_lwdata(lwdata,option_channel_sel);
lwdata= FLW_crop_epochs.get_lwdata(lwdata,option_crop);
data_nontarget=squeeze(lwdata.data);
clc;

fea=[data_nontarget(:,:);data_target(:,:)];
label=[zeros(570,1);ones(30,1)];
[fea, mu, sigma] = zscore(fea); % 对所有特征标准化（均值为0，方差为1）

k=10;
rng(1);
cv = cvpartition(label, 'KFold', k); % 创建 K 折划分

accuracy_values = zeros(k, 1); % 用于存储每折的分类准确率
confusion_matrices = cell(k, 1); % 用于存储每折的混淆矩阵
y_pred=zeros(600,1);
for i = 1:k
    trainIdx = training(cv, i);
    testIdx = test(cv, i);

    % 数据分割
    X_train = fea(trainIdx, :); % 训练数据
    y_train = label(trainIdx);  % 训练标签
    X_test = fea(testIdx, :);   % 测试数据
    y_test = label(testIdx);    % 测试标签

    % 支持向量机 (SVM) 分类器
    SVMModel = fitcsvm(X_train, y_train);

    % 模型预测
    y_pred(testIdx,1) = predict(SVMModel, X_test);
end
accuracy = sum(y_pred == label) / numel(label);
confusion_matrix = confusionmat(label, y_pred);

% 提取混淆矩阵的元素
TP = confusion_matrix(2, 2); % 真正例 (True Positive)
FN = confusion_matrix(2, 1); % 假负例 (False Negative)
FP = confusion_matrix(1, 2); % 假正例 (False Positive)
TN = confusion_matrix(1, 1); % 真负例 (True Negative)

% 计算评估指标
precision = TP / (TP + FP);              % 精确率 (Precision)
recall = TP / (TP + FN);                 % 召回率 (Recall)
f1_score = 2 * (precision * recall) / (precision + recall); % F1-Score

% 输出结果
disp(['分类准确率：', num2str(accuracy * 100), '%']);
disp(['混淆矩阵：']);
disp(confusion_matrix);
disp(['精确率 (Precision)：', num2str(precision)]);
disp(['召回率 (Recall)：', num2str(recall)]);
disp(['F1-Score：', num2str(f1_score)]);
