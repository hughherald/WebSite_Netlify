% 清空环境并读取数据
clc;clear;close all;
num = xlsread('demo_3.xlsx');  % 从Excel文件读取数据

% 统计分析
[h,p1] = ttest(num(:,1),num(:,2));  % 配对t检验
[r,p2] = corr(num(:,1),num(:,2));  % 相关性分析
icc_value = icc31(num);  % 计算ICC(3,1)

% 输出结果
fprintf('均值 (Session1, Session2): [%.4f, %.4f]\n', mean(num(:,1)), mean(num(:,2)));
fprintf('t检验 p值: %.4f\n', p1);
fprintf('相关性系数 r = %.4f, p值 = %.4e\n', r, p2);
fprintf('ICC(3,1)值: %.4f\n', icc_value);


% 绘制散点图和回归线
figure();
hold on; grid on; box on;
axis square;
scatter(num(:,1), num(:,2), 'filled');  % 散点图
p = polyfit(num(:,1), num(:,2), 1);  % 线性拟合
 yfit = polyval(p, num(:,1));
plot(num(:,1), yfit, 'r-');  % 回归线
xlabel('Session 1 Amplitude (μV)');
ylabel('Session 2 Amplitude (μV)');
xlim([0,14]); ylim([0,14]);


function ICC_31 = icc31(data)
    % 计算ICC(3,1) - 用于评估两个测量之间的一致性
    % 输入: data - 大小为n×2的矩阵，每行代表一个被试的两次测量
    % 输出: ICC_31 - ICC(3,1)值
    [n, k] = size(data);
    if k ~= 2, error('icc31函数仅适用于2列数据'); end
    
    grand_mean = mean(data(:));  % 总均值
    row_means = mean(data, 2);   % 每行均值(被试均值)
    
    % 被试间平方和与均方
    SSR = k * sum((row_means - grand_mean).^2);
    MSR = SSR / (n - 1);
    
    % 残差平方和与均方
    SSE = sum(sum((data - repmat(row_means, 1, k)).^2));
    MSE = SSE / (n * (k - 1));
    
    % ICC(3,1)计算公式
    ICC_31 = (MSR - MSE) / (MSR + (k - 1) * MSE);
end
