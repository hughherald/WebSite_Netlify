%% demo_1 - 数据预处理和合并脚本
clc;clear;close all;  % 清空环境

data_source='..\rawdata2\'; % 设置原始数据路径

LW_init();  % 初始化工具箱

option_merge=struct('type','epoch','suffix','merge_epoch','is_save',0); % 设置合并选项：按epoch合并，不保存中间结果
option_avg=struct('operation','average','suffix','avg','is_save',0);% 设置平均选项：对epoch求平均，不保存中间结果

file_condition={'ses1 Nontarget','ses2 Nontarget',...
    'ses1 Target','ses2 Target',...
    'Nontarget',' Target'};


for cond=1:6
    
    ls=dir([data_source,'sub*',file_condition{cond},'.lw6']); % 查找当前条件下的所有被试文件
    % 构建文件列表
    for k=1:length(ls)
        option_load.filename{k}=[data_source,ls(k).name];
    end
    
    lwdataset = FLW_load.get_lwdataset(option_load); % 加载数据    
    lwdata = FLW_merge.get_lwdata(lwdataset,option_merge);% 合并epoch    
    lwdata= FLW_average_epochs.get_lwdata(lwdata,option_avg);% 对epoch求平均

    
    % 保存处理后的数据
    if cond<6
        lwdata.header.name=['ga ',file_condition{cond}];
    else
        lwdata.header.name=['ga',file_condition{cond}];
    end
    CLW_save(lwdata);
end