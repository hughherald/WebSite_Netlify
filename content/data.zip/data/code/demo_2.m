LW_init();option=[];
%% option for figure
option.inputfiles{1}='ga Nontarget.lw6';
option.inputfiles{2}='ga Target.lw6';
option.fig2_pos=[2678.3333,206.3333,1000,400];

%% option.axis{1}: P300
option.ax{1}.name='P300';
option.ax{1}.pos=[80,70,870,300];
option.ax{1}.style='Curve';
option.ax{1}.fontsize=12;
option.ax{1}.box='on';
option.ax{1}.legend='on';
option.ax{1}.XGrid='on';
option.ax{1}.xlabel_visible='on';
option.ax{1}.xlabel='Time [sec]';
option.ax{1}.YGrid='on';
option.ax{1}.ylabel_visible='on';
option.ax{1}.ylabel='Amplitude [\muV]';

%% option.axis{1}.content{1}: line4
option.ax{1}.content{1}.name='line4';
option.ax{1}.content{1}.type='line';
option.ax{1}.content{1}.x=[0,0];
option.ax{1}.content{1}.y=[-4,-0.178];
option.ax{1}.content{1}.style='--';

%% option.axis{1}.content{2}: line5
option.ax{1}.content{2}.name='line5';
option.ax{1}.content{2}.type='line';
option.ax{1}.content{2}.x=[0.324,0.324];
option.ax{1}.content{2}.y=[-4,9.54];
option.ax{1}.content{2}.style='--';

%% option.axis{1}.content{3}: line6
option.ax{1}.content{3}.name='line6';
option.ax{1}.content{3}.type='line';
option.ax{1}.content{3}.x=[0.5,0.5];
option.ax{1}.content{3}.y=[-4,0.41];
option.ax{1}.content{3}.style='--';

%% option.axis{1}.content{4}: Target
option.ax{1}.content{4}.name='Target';
option.ax{1}.content{4}.type='curve';
option.ax{1}.content{4}.dataset=2;
option.ax{1}.content{4}.ch='POz';
option.ax{1}.content{4}.linewidth=3;
option.ax{1}.content{4}.color=[0.85,0.325,0.098];

%% option.axis{1}.content{5}: NonTarget
option.ax{1}.content{5}.name='NonTarget';
option.ax{1}.content{5}.type='curve';
option.ax{1}.content{5}.dataset=1;
option.ax{1}.content{5}.ch='POz';
option.ax{1}.content{5}.linewidth=3;
option.ax{1}.content{5}.color=[0,0.44706,0.74118];

%% option.axis{1}.content{6}: rect3
option.ax{1}.content{6}.name='rect3';
option.ax{1}.content{6}.type='rect';
option.ax{1}.content{6}.x=0.25;
option.ax{1}.content{6}.y=-4;
option.ax{1}.content{6}.w=0.2;
option.ax{1}.content{6}.h=14;
option.ax{1}.content{6}.FaceAlpha=0.25;
option.ax{1}.content{6}.EdgeAlpha=0;

%% option.axis{2}: 0 ms
option.ax{2}.name='0 ms';
option.ax{2}.pos=[230,200,120,120];
option.ax{2}.style='Topograph';
option.ax{2}.fontsize=12;

%% option.axis{2}.content{1}: topo1
option.ax{2}.content{1}.name='topo1';
option.ax{2}.content{1}.type='topo';
option.ax{2}.content{1}.dataset=2;
option.ax{2}.content{1}.x=[0,0];
option.ax{2}.content{1}.dim='2D';
option.ax{2}.content{1}.shrink=0.95;
option.ax{2}.content{1}.headrad=0.5;
option.ax{2}.content{1}.maplimits=[-4,10];
option.ax{2}.content{1}.dotsize=8;
option.ax{2}.content{1}.mark={'POz'};

%% option.axis{3}: 324 ms
option.ax{3}.name='324 ms';
option.ax{3}.pos=[380,200,120,120];
option.ax{3}.style='Topograph';
option.ax{3}.fontsize=12;

%% option.axis{3}.content{1}: topo1
option.ax{3}.content{1}.name='topo1';
option.ax{3}.content{1}.type='topo';
option.ax{3}.content{1}.dataset=2;
option.ax{3}.content{1}.x=[0.324,0.324];
option.ax{3}.content{1}.dim='2D';
option.ax{3}.content{1}.shrink=0.95;
option.ax{3}.content{1}.headrad=0.5;
option.ax{3}.content{1}.maplimits=[-4,10];
option.ax{3}.content{1}.dotsize=8;
option.ax{3}.content{1}.mark={'POz'};

%% option.axis{4}: 500 ms
option.ax{4}.name='500 ms';
option.ax{4}.pos=[650,200,120,120];
option.ax{4}.style='Topograph';
option.ax{4}.fontsize=12;
option.ax{4}.colorbar='on';

%% option.axis{4}.content{1}: topo1
option.ax{4}.content{1}.name='topo1';
option.ax{4}.content{1}.type='topo';
option.ax{4}.content{1}.dataset=2;
option.ax{4}.content{1}.x=[0.5,0.5];
option.ax{4}.content{1}.dim='2D';
option.ax{4}.content{1}.shrink=0.95;
option.ax{4}.content{1}.headrad=0.5;
option.ax{4}.content{1}.maplimits=[-4,10];
option.ax{4}.content{1}.dotsize=8;
option.ax{4}.content{1}.mark={'POz'};
GLW_figure(option);
